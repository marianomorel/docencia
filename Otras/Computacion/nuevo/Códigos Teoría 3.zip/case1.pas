{
* ------------------------------------------------------------------------------------------------------
* Universidad Nacional de Mar del Plata
* Facultad de Ingeniería
* Asignatura: Computación
* ------------------------------------------------------------------------------------------------------
* Tema: Estructuras de decisión (clase 3)
* 
* Ejemplo introductorio al uso de la estructura CASE OF
* 
* Se ingresan 2 números reales y se selecciona la operación básica a ejecutar sobre ellos: suma, resta, multiplicación o división
* ------------------------------------------------------------------------------------------------------
* }

PROGRAM case1;

VAR
	a,b,resultado:real;
	operacion:char;
	op_valida: boolean; 	//true si la operación es válida
BEGIN

	writeln('Ingrese a y b');
	readln(a,b);
	writeln('Ingrese la operacion');
	readln(operacion);

	op_valida:= true;	//iniciamos el booleano en true
	CASE operacion OF
		'a'..'g': begin	//bloque BEGIN..END innecesario, se incluye para mostrar la posibilidad de agrupar varias sentencias en una opción del CASE
					resultado:= a + b;
				 end;
		'h'..'m','t'..'z': resultado:= a - b;	//se combinan varios subrangos en un solo caso
		'o': resultado:= a * b;
		'w': resultado:= a / b;
		ELSE 
			begin
			op_valida:= false;	//si la operación no corresponde a un caso previo, se marca como inválida
			writeln('Operación Inválida');
			end;
	END;

	if op_valida then	//equivalente a op_valida = true
		writeln('El resultado es ',resultado:6:2);
END.
