{
* ------------------------------------------------------------------------------------------------------
* Universidad Nacional de Mar del Plata
* Facultad de Ingeniería
* Asignatura: Computación
* ------------------------------------------------------------------------------------------------------
* Tema: Estructuras de decisión (clase 3)
* 
* Ejemplo introductorio al uso de la estructura IF anidados
* 
* Enunciado: informar si un número entero es positivo, negativo o nulo
* ------------------------------------------------------------------------------------------------------
* }

PROGRAM decision1;

VAR
	a:integer;
	
BEGIN
	writeln('Ingrese a');
	readln(a);
	IF a>0 THEN
		writeln('Es positivo')
	ELSE
		IF a<0 THEN
			writeln('Es negativo')
		ELSE
			writeln('Es nulo');
END.
