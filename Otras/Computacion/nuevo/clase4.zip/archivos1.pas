program archivos1;

var
	archL, archE:text;
	c3,c2,c1,c0,x,P:real;
	nombre:string;
	
begin
	writeln('Ingrese el nombre del archivo');
	readln(nombre);
	assign(archL,nombre + '.txt');
	reset(archL);

	assign(archE,'resultado.txt');
	rewrite(archE);
	
	writeln('Ingrese x');
	readln(x);
	readln(archL,c3,c2,c1,c0);
	close(archL);

	P:= c3*x*x*x + c2 *x*x + c1*x + c0;
	writeln('P(',x:6:0,') = ',P:6:0);
	writeln(archE,x:6:2,P:6:2);
	close(archE);
end.
