program archivos1;

var
	arch:text;
//	serie:word;
	resultado:char;
	contS,contN,contX, N, lata: word;
begin
	assign(arch,'azar.txt');
	reset(arch);

//	writeln('Cuántas latas tenés?');
//	readln(N);
	//Inicializar contadores
	contS:=0;
	contN:=0;
	contX:=0;

	while not(eof(arch)) do
	begin
		readln(arch,resultado);
		case resultado of
			'S': contS:= contS + 1;
			'N': contN:= contN + 1;
			'X': contX:= contX + 1;
		end;
	end;
	writeln('S: ',contS);
	writeln('N: ',contN);
	writeln('X: ',contX);	
	close(arch);
end.
