program archivos1;

var
	arch:text;
	valor:byte;
	lata,N: word;
	resultado: char;
begin
	assign(arch,'azar.txt');
	rewrite(arch);
	randomize;
	writeln('Cuántos datos?');
	readln(N);
	for lata:=1 to N do
		begin
			valor:=random(3);
			case valor of
				0: resultado:= 'S';
				1: resultado:= 'N';
				2: resultado:= 'X';
			end;
			writeln(arch,resultado);
		end;	
	close(arch);
end.
