program ciclos1;
var
	valor,max: byte;

begin
	//mostrar los numeros de 1 a N
	writeln('Ingrese un valor');
	readln(valor);
	max:=valor;
{	while valor<>0 do
		begin
			writeln('Ingrese un valor');
			readln(valor);
			if valor>max then
				max:=valor;
		end;
}
	repeat
			writeln('Ingrese un valor');
			readln(valor);
			if valor>max then
				max:=valor;
	until valor = 0;
	writeln('El maximo es ',max);	


end.
