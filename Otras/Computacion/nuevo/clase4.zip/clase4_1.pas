program ciclos1;
var
	numero,N: byte;

begin
	//mostrar los numeros de 1 a N
	writeln('Ingrese N');
	readln(N);
	numero:=0;
{	while numero<N do
		begin
			numero:= numero + 1;
			writeln(numero);
		end;
}
	repeat
		numero:= numero + 2;
		writeln(numero);
	until numero>=N
end.
