program promedio;

var
	suma,numero:real;
	valores:byte;
	datos,resultados:text;

begin
	assign(datos,'datos.txt');
	reset(datos);
	assign(resultados,'resultados.txt');
	rewrite(resultados);
	suma:=0;
	valores:=0;
	readln(datos,numero);
	while numero<>0 do
		begin
			suma:= suma + numero;
			valores:= valores + 1;
			readln(datos,numero);
		end;
	close(datos);
	writeln(resultados,'El promedio es ',suma/valores:6:2);
	close(resultados);

end.
